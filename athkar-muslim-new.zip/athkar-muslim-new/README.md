# أذكار مسلم
مشروع Android WebView يعمل محلياً دون إنترنت. الواجهة والتخزين محليان داخل `app/src/main/assets/index.html`.

## بناء APK
ارفع محتويات هذا المجلد إلى مستودع GitHub جديد باسم `Athkar-Muslim-New`. من تبويب Actions شغّل `Build Athkar Muslim APK`، ثم نزّل artifact باسم `athkar-muslim-debug-apk` وفك ضغطه لتحصل على `app-debug.apk`.
